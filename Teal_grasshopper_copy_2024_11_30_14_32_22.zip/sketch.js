// Este codigo exibe uma lista visual de campeões da copa do Mundo desde 1930 até o ano mais recente (2022), não houve Copa do Mundo, como em 1942 e 1946, devido á Segunda Guerra Mundial.


let campeoes = [
  {ano:1930, campeao:'Uruguai'},
  {ano:1934, campeao:'Itália'},
  {ano:1938, campeao:'Itália'},
  {ano:1950, campeao:'Uruguai'},
  {ano:1954, campeao:'Alemanha Ocidental'},
  {ano:1958, campeao:'Brasil'},
  {ano:1962, campeao:'Brasil'},
  {ano:1966, campeao:'Inglaterra'},
  {ano:1970, campeao:'Brasil'},
  {ano:1974, campeao:'Alemanha'},
  {ano:1978, campeao:'Argentina'},
  {ano:1982, campeao:'Italia'},
  {ano:1986, campeao:'Argentina'},
  {ano:1990, campeao:'Alemanha'},
  {ano:1994, campeao:'Brasil'},
  {ano:1998, campeao:'França'},
  {ano:2002, campeao:'Brasil'},
  {ano:2006, campeao:'Italia'},
  {ano:2010, campeao:'Espanha'},
  {ano:2014, campeao:'Alemanha'},
  {ano:2018, campeao:'França'},
  {ano:2022, campeao:'Argentina'},
];


let anoSemCopa = [1942,1946]; // Ano Sem copa do mundo devido a Segunda  Guerra Mundial
let resposta = "";

function setup(){
  createCanvas(600,400);
  background(255);
  textSize(16);
  fill(0);
  textAlign(LEFT,TOP);

// Solicitar um ano para o usuário  
let anoConsulta = prompt ("Digetge um ano para saber se teve Copa do Mundo:");


// Verificar se o ano é valido 
if (anoConsulta){
  anoConsulta = int(anoConsulta);

// verificar se o ano tem  Copa do Mundo 
if 
  (anoSemCopa.includes(anoConsulta))
  {
    resposta = `${anoConsulta}: não houve Copa do Mundo devido a segunda Guerra Mundial.`;
  } else {
    let campeao = campeoes . find (c=> c.ano === anoConsulta);
  if (campeao) {
    resposta = `${anoConsulta}: o campeão foi ${campeao.campeao}:`;
  } else {
    resposta = `${anoConsulta}: não houve Copa do Mundo nesse ano.`;               }
    }
  } else {
    resposta = "por favor,insira um ano valido.";
  }
  
  // Exibir a resposta na tela 
  text (resposta,20,20);
}
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  